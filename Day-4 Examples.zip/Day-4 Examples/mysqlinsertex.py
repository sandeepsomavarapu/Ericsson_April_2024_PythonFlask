
import mysql.connector

mydb=mysql.connector.connect(host="localhost",user="root",passwd="rpsconsulting",database="ericsson_hyd")

mycursor=mydb.cursor()

mycursor.execute("insert into ericsson_emps values(127,'rajesh')");

mydb.commit();