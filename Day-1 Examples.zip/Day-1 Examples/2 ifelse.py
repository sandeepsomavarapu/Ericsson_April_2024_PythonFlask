marks = int(input(" Please Enter Your Subject Marks:  ")) #89
if marks >= 50:
    print(" Congratulations ")  # s1
else:
    print(" You are Failed")  # s3
    print(" Better Luck Next Time") #s4
print("outside if-else")