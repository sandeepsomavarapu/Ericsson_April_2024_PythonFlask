class Student:
	id=10
	name="hello"
	def __init__(self,sid,sname):#two param-sconstructor
		self.id=sid
		self.name=sname
	def __init__(self,sid):#one param-constructor #last constructor will be considered when we have many
		self.id=sid
	def add(self,a,b):
		res=a+b
		print("sum of two numbers is : ",res)
s=Student(30)#calling ()
print(s.id)
print(s.name)
s.add(20,30)
s1=Student(20)#
print(s1.id)
print(s1.name)
	