try:
    result = 12 / 0 #PVM
    print("Result is", result)#error code/risky code 
except ArithmeticError:
    print("arithmetic error")
except ZeroDivisionError as obj:
    print("zero division error")
except  Exception:
    print("some other exception")
print("Remaining lines of code")
#system defined error messages
#abnormal termination


#normal ternimation
#user friendly error message 












